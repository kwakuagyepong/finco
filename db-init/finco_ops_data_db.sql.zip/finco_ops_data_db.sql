-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2025 at 04:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finco_ops_data_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `account_id` int(100) NOT NULL,
  `amount` decimal(65,0) NOT NULL,
  `credit_union_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`account_id`, `amount`, `credit_union_id`) VALUES
(1, 500, 'CUI001'),
(2, 100, 'CUI002');

-- --------------------------------------------------------

--
-- Table structure for table `account_deposit_history`
--

CREATE TABLE `account_deposit_history` (
  `deposit_history_id` varchar(100) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `credit_union_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `account_deposit_history`
--
DELIMITER $$
CREATE TRIGGER `before_insert_accounts_deposit_history` BEFORE INSERT ON `account_deposit_history` FOR EACH ROW BEGIN
    DECLARE new_id VARCHAR(10);
    DECLARE last_number INT;
    DECLARE duplicate_count INT;

    -- Get the last generated number
    SELECT last_id INTO last_number FROM sequence_account_deposit_history FOR UPDATE;

    -- Increment the last number by 1
    SET last_number = last_number + 1;

    -- Loop to check for duplicates
    SET duplicate_count = 1;
    SET new_id = CONCAT('ACC', LPAD(last_number, 9, '1'));

    -- Check if the generated ID already exists, and if so, increment the number
    WHILE EXISTS (SELECT 1 FROM account_deposit_history WHERE deposit_history_id = new_id) DO
        SET last_number = last_number + 1;
        SET new_id = CONCAT('TRANS', LPAD(last_number, 9, '1'));
    END WHILE;

    -- Set the new deposit_history_id
    SET NEW.deposit_history_id = new_id;

    -- Update the last generated number in the helper table
    UPDATE sequence_account_deposit_history SET last_id = last_number;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `credentials`
--

CREATE TABLE `credentials` (
  `credencials_id` varchar(50) NOT NULL,
  `Users_ID` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','manager','teller','') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `credentials`
--

INSERT INTO `credentials` (`credencials_id`, `Users_ID`, `password`, `role`, `timestamp`) VALUES
('CRDID001', 'CUU331', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'admin', '2024-08-09 15:22:58'),
('CRDID002', 'CUU333', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'teller', '2024-08-31 10:07:45'),
('CRDID003', 'CUU334', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'manager', '2024-08-31 10:07:45'),
('CRDID015', 'CUU335', '583201c1efbf30eb13b79352ab6ebd35103ec347953d8e99858a57b5bab3dde9', 'manager', '2025-02-04 13:44:08');

--
-- Triggers `credentials`
--
DELIMITER $$
CREATE TRIGGER `before_insert_credentials` BEFORE INSERT ON `credentials` FOR EACH ROW BEGIN
    DECLARE new_id VARCHAR(10);
    DECLARE last_number INT;

    -- Get the last generated number
    SELECT last_id INTO last_number FROM credentials_ID_Sequence FOR UPDATE;

    -- Increment the last number by 1
    SET last_number = last_number + 1;

    -- Create the new custom Rating_id
    SET new_id = CONCAT('CRDID', LPAD(last_number, 3, '0'));

    -- Set the new Rating_id
    SET NEW.credencials_id = new_id;

    -- Update the last generated number in the helper table
    UPDATE credentials_ID_Sequence SET last_id = last_number;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `credentials_id_sequence`
--

CREATE TABLE `credentials_id_sequence` (
  `last_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `credentials_id_sequence`
--

INSERT INTO `credentials_id_sequence` (`last_id`) VALUES
(15);

-- --------------------------------------------------------

--
-- Table structure for table `sequence_account_deposit_history`
--

CREATE TABLE `sequence_account_deposit_history` (
  `last_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`account_id`),
  ADD KEY `fk_account_credit_union` (`credit_union_id`);

--
-- Indexes for table `account_deposit_history`
--
ALTER TABLE `account_deposit_history`
  ADD PRIMARY KEY (`deposit_history_id`);

--
-- Indexes for table `credentials`
--
ALTER TABLE `credentials`
  ADD PRIMARY KEY (`credencials_id`),
  ADD KEY `Users_ID` (`Users_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `account_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `fk_account_credit_union` FOREIGN KEY (`credit_union_id`) REFERENCES `creditunions` (`credit_union_id`) ON UPDATE CASCADE;

--
-- Constraints for table `credentials`
--
ALTER TABLE `credentials`
  ADD CONSTRAINT `credentials_ibfk_1` FOREIGN KEY (`Users_ID`) REFERENCES `users_of_credit_union` (`credit_union_user_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
